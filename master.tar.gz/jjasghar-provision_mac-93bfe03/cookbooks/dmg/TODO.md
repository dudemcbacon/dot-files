TODO
====
A few things remain outstanding to make this cookbook "1.0" quality.

- support downloading a .dmg.zip and unzipping it
- specify a local .dmg already downloaded in another location (like ~/Downloads)

Some things that would be nice to have at some point.

- use hdiutil to mount/attach the disk image
- automatically detect the `volumes_dir` where the image is attached
- be able to automatically accept license agreements
