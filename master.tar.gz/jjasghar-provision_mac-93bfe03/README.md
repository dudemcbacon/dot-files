# My mac provisioning system

Simply said all you need:
```bash
[~] % curl -L http://bit.ly/jj_mac > run.sh && bash run.sh
```
